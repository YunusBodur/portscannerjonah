#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os

os.system("apt-get install figlet")
os.system("clear")
os.system("figlet Port Scanner")

print("""
WELCOME TO PORT SCANNER
Developer => @Gigafarad

1) quick scan
2) service and version information
3) operating system information
""")

Transaction_Number = raw_input("Enter the Transaction Number: ")

if(Transaction_Number == "1"):

	targetip = raw_input("Enter the Target IP: ")
	os.system("nmap " + targetip)

elif(Transaction_Number=="2"):

	targetip = raw_input("Enter the Target IP: ")
	os.system("nmap -sS -sV " + targetip)

elif(Transaction_Number=="3"):

	tarhetip = raw_input("Enter the Target IP: ")
	os.system("nmap -o " + targetip)

else:
	print (" You entered incorrectly. Shutting down.")
